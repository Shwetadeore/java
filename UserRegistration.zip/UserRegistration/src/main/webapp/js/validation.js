function validate(frm){

document.getElementById("unameErr").innerHTML="";
document.getElementById("uaddErr").innerHTML="";
document.getElementById("umailidErr").innerHTML="";
document.getElementById("umobnoErr").innerHTML="";
document.getElementById("pwErr").innerHTML="";

var name=frm.userName.value;
var address=frm.address.value;
var emailId=frm.emailId.value;
var mobileNo=frm.mobileNumber.value;
var password=frm.password.value;
var flag=true;
var emailCheck = /\S+@\S+\.\S+/;

if(name == ""){
	document.getElementById("unameErr").innerHTML="User name is required";
	flag = false;
} 
else if(name.length > 20){
	document.getElementById("unameErr").innerHTML="User name Should be less than 20 Character";
	flag = false;
}

if(address == ""){
	document.getElementById("uaddErr").innerHTML="User Adress is required";
	flag = false;
}
else if(address.length > 50) {
	document.getElementById("uaddErr").innerHTML="User Address must be within 50 letter";
	flag = false;

}

if(mobileNo == "") {
	document.getElementById("umobnoErr").innerHTML="Enter valid phone number";
	flag = false;
}

if(!emailCheck.test(emailId)){
	document.getElementById("umailidErr").innerHTML="Enter valid Email Id";
	flag = false;
}

if(password == "") {
	document.getElementById("pwErr").innerHTML="Enter the password please";
	flag = false;
}
else if(password.legth < 8 || password > 20) {
	document.getElementById("pwErr").innerHTML="User password length must be between 8 to 20";
	flag = false;
}

return flag;
}
	