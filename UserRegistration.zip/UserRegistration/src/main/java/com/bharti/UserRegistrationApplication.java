package com.bharti;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.bharti.model.User;

@SpringBootApplication
public class UserRegistrationApplication {

	public static void main(String[] args) {
		ApplicationContext ctx = SpringApplication.run(UserRegistrationApplication.class, args);
		User user = new User();

	}
}
