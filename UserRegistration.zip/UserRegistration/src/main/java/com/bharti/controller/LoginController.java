package com.bharti.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.bharti.model.User;
import com.bharti.service.IUserService;

@Controller
public class LoginController {

	@Autowired
	private IUserService userService;
	
	@Autowired
	private JavaMailSender mailSender;

	@RequestMapping({ "/", "/home" })
	public String home() {
		return "input";
	}

	@PostMapping("/register")
	public ModelAndView userRegistration(User user) throws Exception {
		//emailVerfication method call
		//sendMail(user);
		String result = userService.insertUser(user);
		ModelAndView modelAndView = new ModelAndView("home");
		modelAndView.addObject("result", result);
		return modelAndView;
	}

	@GetMapping("/fetch")
	public ModelAndView fetchAllResults() throws Exception {
		List<User> listUser = userService.fetchUserDetails();
		ModelAndView modelAndView = new ModelAndView("fetchRecord");
		modelAndView.addObject("listUser", listUser);
		return modelAndView;
	}
	
	public void sendMail(User user)
	{
		SimpleMailMessage message = new SimpleMailMessage();
		message.setFrom("shwetadeore99@gmail.com");
		message.setTo("npawar774@gmail.com");
		
		String mailSubject = user.getUserName()+ " has sent mail";
		String mailContent = "Sender Name: " + user.getUserName() + "\n";
		mailContent += "Sender E - mail: " + user.getEmailId() + "\n";
		mailContent += "Varify Mail" + "\n";
		
		message.setSubject(mailSubject);
		message.setText(mailContent);
		
		mailSender.send(message);
	}

}
