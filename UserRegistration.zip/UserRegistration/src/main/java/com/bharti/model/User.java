package com.bharti.model;

public class User {

	private String userName;
	private String address;
	private String emailId;
	private String mobileNumber;
	private String password;

	public final String getUserName() {
		return userName;
	}

	public final void setUserName(String userName) {
		this.userName = userName;
	}

	public final String getAddress() {
		return address;
	}

	public final void setAddress(String address) {
		this.address = address;
	}

	public final String getEmailId() {
		return emailId;
	}

	public final void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public final String getMobileNumber() {
		return mobileNumber;
	}

	public final void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
}
