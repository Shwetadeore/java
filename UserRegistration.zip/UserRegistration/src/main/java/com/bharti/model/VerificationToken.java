package com.bharti.model;

import java.util.Date;

public class VerificationToken {

	private static final int EXPIRATION = 60 * 24;

	private int id;

	private String token;
	private Date createDate;
	private Date expiryDate;
	
	public final int getId() {
		return id;
	}
	public final void setId(int id) {
		this.id = id;
	}
	public final String getToken() {
		return token;
	}
	public final void setToken(String token) {
		this.token = token;
	}
	public final Date getCreateDate() {
		return createDate;
	}
	public final void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}
	public final Date getExpiryDate() {
		return expiryDate;
	}
	public final void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}
	public static final int getExpiration() {
		return EXPIRATION;
	}

}
