package com.bharti.dao;

import java.util.List;

import com.bharti.model.User;

public interface IUserDao {
	
	public int registerUser(User user )throws Exception;
	public List<User> getAllDetails()throws Exception;

}
