package com.bharti.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.bharti.model.User;

@Repository("userDao")
public class UserDaoImpl implements IUserDao {
	private static final String USER_INSERT_QUERY = "INSERT INTO USERDATA VALUES(USERDATA_SEQ.nextVal,?,?,?,?,?)";
	private static final String USER_SELECT_QUERY = "SELECT * FROM USERDATA";

	@Autowired
	private DataSource dataSource;
	private int count;

	@Override
	public int registerUser(User user) throws SQLException {
		try {
			Connection connection = dataSource.getConnection();
			PreparedStatement preparedStatement = connection.prepareStatement(USER_INSERT_QUERY);
			preparedStatement.setString(1, user.getUserName());
			preparedStatement.setString(2, user.getAddress());
			preparedStatement.setString(3, user.getEmailId());
			preparedStatement.setString(4, user.getMobileNumber());
			preparedStatement.setString(5, user.getPassword());
			count =  preparedStatement.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return count;
	}

	@Override
	public List<User> getAllDetails() throws Exception {
		List<User> listUser = null;
		try {
			Connection connection = dataSource.getConnection();
			PreparedStatement preparedStatement = connection.prepareStatement(USER_SELECT_QUERY);
			ResultSet resultSet = preparedStatement.executeQuery();
			listUser = new ArrayList();
			while (resultSet.next()) {
				User user = new User();
				user.setUserName(resultSet.getString(2));
				user.setAddress(resultSet.getString(3));
				user.setEmailId(resultSet.getString(4));
				user.setMobileNumber(resultSet.getString(5));
				user.setPassword(resultSet.getString(6));

				listUser.add(user);
			}
		} catch (SQLException se) {
			se.printStackTrace();
			System.out.println("Internal Problem");
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Unknow Problem");
		}
		return listUser;
	}

}
