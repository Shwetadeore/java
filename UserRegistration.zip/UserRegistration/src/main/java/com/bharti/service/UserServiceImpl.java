package com.bharti.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bharti.dao.IUserDao;
import com.bharti.model.User;

@Service("userService")
public class UserServiceImpl implements IUserService {
	
	@Autowired
	private IUserDao iUserDao;

	@Override
	public String insertUser(User user) throws Exception {
		int count = iUserDao.registerUser(user);
		if (count == 0) {
			return "User Record not insert";
		}
		else {
			return "User Record inserted";
	}
	}

	@Override
	public List<User> fetchUserDetails() throws Exception {
		List<User>listUser=iUserDao.getAllDetails();
		
		return listUser;
	}

}
