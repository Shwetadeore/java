package com.bharti.service;

import java.util.List;

import com.bharti.model.User;

public interface IUserService {
	
	public String insertUser(User user)throws Exception;

	public List<User> fetchUserDetails()throws Exception;
	
	//public void createVerificationToken(Person person,String token)throws Exception;
       
}
